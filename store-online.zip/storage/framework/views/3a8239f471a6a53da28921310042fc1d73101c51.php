<!DOCTYPE html>
<html lang="en">
<head>

 <?php echo $__env->make('layouts.backend.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

<div class="wrapper">




    <?php echo $__env->make('layouts.backend.main-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!--Main content -->
<div class="main-content app-content">

<?php echo $__env->make('layouts.backend.main-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!--container-->
<div class="container-fluid">

    <div class="row">


         <div class="content-wrapper">
                   <?php echo $__env->yieldContent('page-title'); ?>
                   <?php echo $__env->yieldContent('content'); ?>
                   <?php echo $__env->make('layouts.backend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



          </div><!-- main content wrapper end-->
       </div><!-- row end-->
     </div><!-- container-fluid end-->
   </div><!--main-content end-->
</div><!-- wrapper end-->


<?php echo $__env->make('layouts.backend.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\laragon\www\store-online\resources\views/layouts/backend/master.blade.php ENDPATH**/ ?>