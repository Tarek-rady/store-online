<?php $__env->startSection('title'); ?>
HomeSlider
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>

<div class="page-title">

    <div class="row">
      <div class="col-sm-4">
          <h4 class="mb-0"> Dashboard</h4>
      </div>

      <div class="col-sm-8">
        <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(url('admin')); ?>" class="default-color">Dashboard</a></li>
          <li class="breadcrumb-item active">sliders</li>
        </ol>
      </div>
    </div>

  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
               <div class="card card-statistics h-100">
                   <div class="card-body">

                       
                       <div class="row">
                           <a href="<?php echo e(route('sliders.create')); ?>"> <button type="button" class="button x-small">
                            add slider
                           </button></a>

                       </div><br>

                       <div class="table-responsive">
                           <table id="datatable" class="table table-striped table-bordered p-0 text-center table-hover">
                               <thead>
                               <tr>
                                   <th>#</th>
                                   <th>image</th>
                                   <th>title </th>
                                   <th>subtitle</th>
                                   <th>price</th>
                                   <th>link</th>
                                   <th>status</th>
                                   <th>Action</th>
                               </tr>
                               </thead>
                               <tbody>
                               <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                       <td><?php echo e($loop->index +1); ?></td>
                                       <td>
                                        <img src="<?php echo e(asset('assets/images/slider/'.$slider->image)); ?>" width="110px" alt="">
                                       </td>
                                       <td><?php echo e($slider->title); ?></td>
                                       <td><?php echo e($slider->subtitle); ?></td>
                                       <td><?php echo e($slider->price); ?></td>
                                       <td><?php echo e($slider->link); ?></td>
                                       <td><?php echo e($slider->status); ?></td>


                                        <td>
                                        <a href="<?php echo e(route('sliders.edit', $slider->id)); ?>" class="btn btn-info btn-sm" title="تعديل" role="button" aria-pressed="true"><i class="fa fa-edit"></i></a>
                                        <button class="btn btn-danger btn-sm" title="حذف" data-toggle="modal"
                                                data-target="#Deleted<?php echo e($slider->id); ?>"><i class="fa fa-trash"></i>
                                        </button>

                                       </td>
                                   </tr>
                                   <?php echo $__env->make('admin.sliders.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tbody>
                           </table>
                       </div>
                   </div>

               </div>
           </div>

       </div>
       <!-- row closed -->



<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\tarek\htdocs\laravel\store-online\resources\views/admin/sliders/index.blade.php ENDPATH**/ ?>