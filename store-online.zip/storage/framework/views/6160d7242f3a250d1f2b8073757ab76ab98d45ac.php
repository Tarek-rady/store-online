<?php $__env->startSection('title'); ?>
OrderDetails
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>

<div class="page-title">

    <div class="row">
      <div class="col-sm-4">
          <h4 class="mb-0"> Dashboard</h4>
      </div>

      <div class="col-sm-8">
        <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(url('admin')); ?>" class="default-color">Home</a></li>
          <li class="breadcrumb-item active">orders</li>
        </ol>
      </div>
    </div>

  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<!-- row -->
<div class="row row-sm">

    <div class="col-xl-12">
        <!-- div -->
        <div class="card mg-b-20" id="tabs-style2">
            <div class="card-body">
                <div class="text-wrap">
                    <div class="example">
                        <div class="panel panel-primary tabs-style-2">
                            <div class=" tab-menu-heading">

                                <div class="tabs-menu1">
                                    <!-- Tabs -->
                                    <ul class="nav panel-tabs main-nav-line">
                                        <li><a href="#tab4" class="nav-link active" data-toggle="tab">order</a></li>
                                        <li><a href="#tab5" class="nav-link" data-toggle="tab">orderItem</a></li>
                                        <li><a href="#tab6" class="nav-link" data-toggle="tab">transaction</a></li>
                                    </ul>
                                </div>
                            </div>


                            <div class="panel-body tabs-menu-body main-content-body-right border">
                                <div class="tab-content">


                                    <div class="tab-pane active" id="tab4">
                                        <div class="table-responsive mt-15">

                                            <table class="table table-striped table-success" style="text-align:center">
                                                <tbody>
                                                    <tr>
                                                        <th scope="row">user name</th>
                                                        <td><?php echo e($order->user_id); ?></td>
                                                        <th scope="row">subtotal</th>
                                                        <td><?php echo e($order->subtotal); ?></td>
                                                        <th scope="row">discount</th>
                                                        <td><?php echo e($order->discount); ?></td>
                                                        <th scope="row">tax</th>
                                                        <td><?php echo e($order->tax); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <th scope="row">total</th>
                                                        <td><?php echo e($order->total); ?></td>
                                                        <th scope="row">FirstName</th>
                                                        <td><?php echo e($order->FirstName); ?></td>
                                                        <th scope="row">LastName</th>
                                                        <td><?php echo e($order->LastName); ?></td>
                                                        <th scope="row">mopile</th>
                                                        <td><?php echo e($order->mopile); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <th scope="row">email</th>
                                                        <td><?php echo e($order->email); ?></td>
                                                        <th scope="row">line1</th>
                                                        <td><?php echo e($order->line1); ?></td>
                                                        <th scope="row">line2</th>
                                                        <td><?php echo e($order->line2); ?></td>
                                                        <th scope="row">city</th>
                                                        <td><?php echo e($order->city); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <th scope="row">province</th>
                                                        <td><?php echo e($order->province); ?></td>
                                                        <th scope="row">country</th>
                                                        <td><?php echo e($order->country); ?></td>
                                                        <th scope="row">zipcode</th>
                                                        <td><?php echo e($order->zipcode); ?></td>
                                                        <th scope="row">status</th>
                                                        <td><?php echo e($order->status); ?></td>

                                                    </tr>

                                                    <tr>
                                                        <th scope="row">order date</th>
                                                        <td><?php echo e($order->created_at); ?></td>
                                                    </tr>


                                                </tbody>
                                            </table>

                                        </div>
                                    </div>

                                    <div class="tab-pane" id="tab5">
                                        <div class="table-responsive mt-15">

                                            <div class="wrap-iten-in-cart">

                                                  <h3 class="box-title">Products Name</h3>

                                                  <ul class="products-cart">
                                                      <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                          <li class="pr-cart-item">
                                                              <div class="product-image">
                                                                  <figure><img src="<?php echo e(asset ('assets/images/products')); ?>/<?php echo e($item->products->image); ?>" alt="<?php echo e($item->products->image); ?>" width="60px"></figure>
                                                              </div>
                                                              <div class="product-name">
                                                                  <a class="link-to-product" href="<?php echo e(route('details.products' , $item->products->slug)); ?>"><?php echo e($item->products->name); ?></a>
                                                              </div>
                                                              <div class="price-field produtc-price"><p class="price">$<?php echo e($item->price); ?></p></div>
                                                              <div class="quantity">
                                                                  <div class="quantity-input">
                                                                    $<?php echo e($item->quantity); ?>


                                                                  </div>
                                                              </div>
                                                              <div class="price-field sub-total"><p class="price">$<?php echo e($item->price * $item->quantity); ?></p></div>

                                                          </li>
                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                  </ul>


                                              </div>

                                        </div>
                                    </div>

                                    <div class="tab-pane" id="tab6">
                                        <div class="table-responsive mt-15">
                                            <table class="table table-striped table-success" style="text-align:center">
                                                <tbody>
                                                    <tr>
                                                        <th scope="row">mode</th>
                                                        <td><?php echo e($order->transaction->mode); ?></td>
                                                        <th scope="row">order</th>
                                                        <td><?php echo e($order->transaction->order_id); ?></td>

                                                    </tr>

                                                    <tr>
                                                        <th scope="row">status</th>
                                                        <td><?php echo e($order->transaction->status); ?></td>
                                                        <th scope="row">order date</th>
                                                        <td><?php echo e($order->transaction->created_at); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <th scope="row">order date</th>
                                                        <td><?php echo e($order->created_at); ?></td>e
                                                    </tr>


                                                </tbody>
                                            </table>

                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /div -->
    </div>

</div>
<!-- /row -->




<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\tarek\htdocs\laravel\store-online\resources\views/admin/orders/details.blade.php ENDPATH**/ ?>