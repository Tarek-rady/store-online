<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">

                <?php if(Session::has('massage')): ?>

                 <div class="alert alert-success"><?php echo e(Session::get('massage')); ?></div>

                <?php endif; ?>


                <form class="form-horizontal" wire:submit.prevent="UpdateHomeCatigory">
                    <div class="form-group">


                        <div class="col" wire:ignore>
                            <label class="control-lable" >catigory</label>
                            <select class="sel_categories form-control" name="catigories[]" multiple="multiple"wire:model="selected_catigories">
                                <?php $__currentLoopData = $Catigories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catigory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($catigory->id); ?>"><?php echo e($catigory->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select><br>

                        </div>


                        <div class="col">
                            <label for="title">no of products</label>
                            <input type="number"  class="form-control" wire:model="numberofproducts">

                        </div>


                        <button class="btn btn-success btn-sm nextBtn btn-lg pull-right" type="submit">submit</button>








                    </div>
                </form>



            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>

 <script>
     $(document).ready(function(){
            $('.sel_categories').select2();
            $('.sel_categories').on('change', function(e){
                var data = $('.sel_catigories').select2("val");
                window.livewire.find('<?php echo e($_instance->id); ?>').set('selected_catigories' , data);

            });

     });
 </script>

<?php $__env->stopPush(); ?>
<?php /**PATH F:\tarek\htdocs\laravel\store-online\resources\views/livewire/admin/admin-home-catigory.blade.php ENDPATH**/ ?>