
  <!-- delete -->
  <div class="modal" id="Deleted<?php echo e($slider->id); ?>">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content modal-content-demo">
            <div class="modal-header">
                <h6 class="modal-title"> Delete slider </h6><button aria-label="Close" class="close" data-dismiss="modal"
                        type="button"><span aria-hidden="true">&times;</span></button>
            </div>

            <form action="<?php echo e(route('sliders.destroy' ,  $slider->id)); ?>" method="post">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <p>are sure of the deleting process ?</p><br>

                    <input class="form-control" name="title" id="title" value="<?php echo e($slider->title); ?>" type="text">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">close</button>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </div>
        </div>
        </form>
    </div>
</div>


<?php /**PATH F:\tarek\htdocs\laravel\store-online\resources\views/admin/sliders/delete.blade.php ENDPATH**/ ?>