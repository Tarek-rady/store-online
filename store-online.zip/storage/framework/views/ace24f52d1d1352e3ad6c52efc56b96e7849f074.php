<div class="wrap-icon-section minicart">
    <a href="<?php echo e(route('cart.products')); ?>" class="link-direction">
        <i class="fa fa-shopping-basket" aria-hidden="true"></i>
        <div class="left-info">
            <span class="index"><?php echo e(Cart::instance('cart')->count()); ?> items</span>
            <span class="title">CART</span>


        </div>
    </a>
</div>
<?php /**PATH F:\tarek\htdocs\laravel\store-online\resources\views/livewire/cart-count-component.blade.php ENDPATH**/ ?>