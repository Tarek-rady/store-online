<?php $__env->startSection('title'); ?>
Catigory
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>

<div class="page-title">

    <div class="row">
      <div class="col-sm-4">
          <h4 class="mb-0"> Dashboard</h4>
      </div>

      <div class="col-sm-8">
        <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(url('admin')); ?>" class="default-color">Dashboard</a></li>
          <li class="breadcrumb-item active">catigries</li>
        </ol>
      </div>
    </div>

  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<!-- row -->
<?php echo $__env->make('admin.massage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-md-12 mb-30">
               <div class="card card-statistics h-100">
                   <div class="card-body">


                       
                       <div class="row">
                            <button type="button" class="button x-small" data-toggle="modal" data-target="#AddCatigory">
                            add catigory
                           </button>

                           <?php echo $__env->make('admin.catigory.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




                       </div><br>

                       <div class="table-responsive">
                           <table id="datatable" class="table table-striped table-bordered p-0 text-center table-hover">
                               <thead>
                               <tr>
                                   <th>#</th>
                                   <th> catigory name  </th>
                                   <th> slug </th>
                                   <th>Action</th>
                               </tr>
                               </thead>
                               <tbody>
                               <?php $__currentLoopData = $Catigories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Catigory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                       <td><?php echo e($loop->index +1); ?></td>
                                       <td><?php echo e($Catigory->name); ?></td>
                                       <td><?php echo e($Catigory->slug); ?></td>
                                        <td>
                                        <button class="btn btn-success btn-sm" title="تعديل" data-toggle="modal"
                                                    data-target="#Edit<?php echo e($Catigory->id); ?>"><i class="fa fa-edit"></i>
                                            </button>


                                        <button class="btn btn-danger btn-sm" title="حذف" data-toggle="modal"
                                                data-target="#Delete<?php echo e($Catigory->id); ?>"><i class="fa fa-trash"></i>
                                        </button>

                                       </td>
                                   </tr>

                                   <?php echo $__env->make('admin.catigory.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                   <?php echo $__env->make('admin.catigory.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tbody>
                           </table>
                       </div>
                   </div>

               </div>
           </div>

       </div>
       <!-- row closed -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\tarek\htdocs\laravel\store-online\resources\views/admin/catigory/index.blade.php ENDPATH**/ ?>