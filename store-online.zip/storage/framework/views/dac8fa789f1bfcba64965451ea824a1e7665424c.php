<!-- jquery -->


<script src="<?php echo e(URL::asset('backend/assets/js/jquery-3.3.1.min.js')); ?>"></script>
<!-- plugins-jquery -->
<script src="<?php echo e(URL::asset('backend/assets/js/plugins-jquery.js')); ?>"></script>
<!-- plugin_path -->
<script type="text/javascript">var plugin_path = '<?php echo e(asset('backend/assets/js')); ?>/';</script>
<!-- chart -->
<script src="<?php echo e(URL::asset('backend/assets/js/chart-init.js')); ?>"></script>
<link href="<?php echo e(asset('backend/assets/css/fontawesome/js/all.js')); ?>" rel="stylesheet">

<!-- lobilist -->
<script src="<?php echo e(URL::asset('backend/assets/js/lobilist.js')); ?>"></script>
<!-- custom -->
<script src="<?php echo e(URL::asset('backend/assets/js/custom.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>


<?php /**PATH D:\laragon\www\store-online\resources\views/layouts/backend/script.blade.php ENDPATH**/ ?>