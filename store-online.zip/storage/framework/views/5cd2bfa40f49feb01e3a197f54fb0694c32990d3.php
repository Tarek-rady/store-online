<?php $__env->startSection('title'); ?>
Products
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>

<div class="page-title">

    <div class="row">
      <div class="col-sm-4">
          <h4 class="mb-0"> Dashboard</h4>
      </div>

      <div class="col-sm-8">
        <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(url('admin')); ?>" class="default-color">Dashboard</a></li>
          <li class="breadcrumb-item active">Products</li>
        </ol>
      </div>
    </div>

  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.massage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
               <div class="card card-statistics h-100">
                   <div class="card-body">

                       
                       <div class="row">
                           <a href="<?php echo e(route('products.create')); ?>"> <button type="button" class="button x-small">
                            add product
                           </button></a>

                       </div><br>

                       <div class="table-responsive">
                           <table id="datatable" class="table table-striped table-bordered p-0 text-center table-hover">
                               <thead>
                               <tr>
                                   <th>#</th>
                                   <th>name </th>
                                   <th>slug</th>
                                   <th>price</th>
                                   <th>sel_price</th>
                                   <th>SKU</th>
                                   <th>stock_status</th>
                                   <th>quantity</th>
                                   <th>image</th>
                                   <th>catgory</th>
                                   <th>Action</th>
                               </tr>
                               </thead>
                               <tbody>
                               <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                       <td><?php echo e($loop->index +1); ?></td>
                                       <td><?php echo e($Product->name); ?></td>
                                       <td><?php echo e($Product->slug); ?></td>
                                       <td><?php echo e($Product->price); ?></td>
                                       <td><?php echo e($Product->sel_price); ?></td>
                                       <td><?php echo e($Product->SKU); ?></td>
                                       <td><?php echo e($Product->stock_status); ?></td>
                                       <td><?php echo e($Product->quantity); ?></td>
                                       <td><?php echo e($Product->image); ?></td>
                                       <td><?php echo e($Product->catigorie_id); ?></td>

                                        <td>
                                        <a href="<?php echo e(route('products.edit' ,$Product->id )); ?>" class="btn btn-info btn-sm" title="تعديل" role="button" aria-pressed="true"><i class="fa fa-edit"></i></a>


                                        <button class="btn btn-danger btn-sm" title="حذف" data-toggle="modal"
                                                data-target="#Deleted<?php echo e($Product->id); ?>"><i class="fa fa-trash"></i>
                                        </button>

                                       </td>
                                   </tr>
                                <?php echo $__env->make('admin.product.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tbody>
                           </table>
                       </div>
                   </div>

               </div>
           </div>

       </div>
       <!-- row closed -->




<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\tarek\htdocs\laravel\store-online\resources\views/admin/product/index.blade.php ENDPATH**/ ?>