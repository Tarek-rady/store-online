<script src="{{ asset ('assets/js/jquery-1.12.4.minb8ff.js?ver=1.12.4')}}"></script>
	<script src="{{ asset ('assets/js/jquery-ui-1.12.4.minb8ff.js?ver=1.12.4')}}"></script>
	<script src="{{ asset ('assets/js/bootstrap.min.js')}}"></script>
	<script src="{{ asset ('assets/js/jquery.flexslider.js')}}"></script>
	{{-- <script src="{{ asset ('assets/js/chosen.jquery.min.js')}}"></script> --}}
	<script src="{{ asset ('assets/js/owl.carousel.min.js')}}"></script>
	<script src="{{ asset ('assets/js/jquery.countdown.min.js')}}"></script>
	<script src="{{ asset ('assets/js/jquery.sticky.js')}}"></script>
	<script src="{{ asset ('assets/js/functions.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/noUiSlider/15.5.0/nouislider.min.js" integrity="sha512-ZKqmaRVpwWCw7S7mEjC89jDdWRD/oMS0mlfH96mO0u3wrPYoN+lXmqvyptH4P9mY6zkoPTSy5U2SwKVXRY5tYQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    @stack('scripts')
    @livewireScripts
