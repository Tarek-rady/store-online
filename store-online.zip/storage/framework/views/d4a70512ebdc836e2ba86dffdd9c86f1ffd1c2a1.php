<div class="wrap-icon-section wishlist">
    <a href="<?php echo e(route('wishlist.products')); ?>" class="link-direction">
        <i class="fa fa-heart" aria-hidden="true"></i>
        <div class="left-info">
            <span class="index"><?php echo e(Cart::instance('wishlist')->count()); ?> item</span>
            <span class="title">Wishlist</span>
        </div>
    </a>
</div>
<?php /**PATH F:\tarek\htdocs\laravel\store-online\resources\views/livewire/wishlist-count-component.blade.php ENDPATH**/ ?>