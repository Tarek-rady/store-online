<!DOCTYPE html>
<html lang="en">
<head>
<?php echo $__env->make('layouts.website.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body class="home-page home-01 ">

	<!-- mobile menu -->
    <div class="mercado-clone-wrap">
        <div class="mercado-panels-actions-wrap">
            <a class="mercado-close-btn mercado-close-panels" href="#">x</a>
        </div>
        <div class="mercado-panels"></div>
    </div>

	<!--header-->
    <?php echo $__env->make('layouts.website.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--header End-->

   	<!--main-->
	   <?php echo e($slot); ?>

    <!--main End-->

	<!--footer-->
     <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('footer-component')->html();
} elseif ($_instance->childHasBeenRendered('GXekccl')) {
    $componentId = $_instance->getRenderedChildComponentId('GXekccl');
    $componentTag = $_instance->getRenderedChildComponentTagName('GXekccl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GXekccl');
} else {
    $response = \Livewire\Livewire::mount('footer-component');
    $html = $response->html();
    $_instance->logRenderedChild('GXekccl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <!--footer End-->


   <!--script -->
    <?php echo $__env->make('layouts.website.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


   <!--script End-->
</body>
</html>

<?php /**PATH D:\laragon\www\store-online\resources\views/layouts/website/site.blade.php ENDPATH**/ ?>