<?php $__env->startSection('title'); ?>
orders
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>

<div class="page-title">

    <div class="row">
      <div class="col-sm-4">
          <h4 class="mb-0"> Dashboard</h4>
      </div>

      <div class="col-sm-8">
        <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(url('admin')); ?>" class="default-color">Home</a></li>
          <li class="breadcrumb-item active">orders</li>
        </ol>
      </div>
    </div>

  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<!-- row -->

<div class="row">
    <div class="col-md-12 mb-30">
               <div class="card card-statistics h-100">
                   <div class="card-body">

                       </div><br>

                       <div class="table-responsive">
                           <table id="datatable" class="table table-striped table-bordered p-0 text-center table-hover">
                               <thead>
                               <tr>
                                   <th>#</th>
                                   <th> order name  </th>
                                   <th> subtotal </th>
                                   <th> discount </th>
                                   <th> tax </th>
                                   <th> total </th>
                                   <th> FirstName </th>
                                   <th> LastName </th>
                                   <th> mopile </th>
                                   <th> email </th>
                                   <th>zipcode</th>
                                   <th>status</th>
                                   <th>order Date</th>
                                   <th> Action </th>
                               </tr>
                               </thead>
                               <tbody>
                               <?php $__currentLoopData = $Orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                        <td><?php echo e($loop->index +1); ?></td>
                                        <td><?php echo e($Order->User->name); ?></td>
                                        <td>$<?php echo e($Order->subtotal); ?></td>
                                        <td>$<?php echo e($Order->discount); ?></td>
                                        <td>$<?php echo e($Order->tax); ?></td>
                                        <td>$<?php echo e($Order->total); ?></td>
                                        <td><?php echo e($Order->FirstName); ?></td>
                                        <td><?php echo e($Order->LastName); ?></td>
                                        <td><?php echo e($Order->mopile); ?></td>
                                        <td><?php echo e($Order->email); ?></td>
                                        <td><?php echo e($Order->zipcode); ?></td>
                                        <td><?php echo e($Order->status); ?></td>
                                        <td><?php echo e($Order->created_at); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('admin/orderDetails' ,$Order->id )); ?>" class="btn btn-info btn-sm">OrderDetails</a>


                                        </td>


                                   </tr>



                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tbody>
                           </table>
                       </div>
                   </div>

               </div>
           </div>

       </div>
       <!-- row closed -->




<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\tarek\htdocs\laravel\store-online\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>